import { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Bed, Patient, Sector, SECTORS } from '@/types/bed';

const initializeBeds = (): Bed[] => {
  const beds: Bed[] = [];

  SECTORS.forEach((sector) => {
    sector.beds.forEach((bedNumber) => {
      beds.push({
        id: `${sector.id}-${bedNumber}`,
        number: bedNumber,
        sector: sector.id,
        patient: null,
      });
    });

    if (sector.extraBeds) {
      sector.extraBeds.forEach((extraName) => {
        beds.push({
          id: `${sector.id}-${extraName.toLowerCase().replace(/\s+/g, '-')}`,
          number: extraName,
          sector: sector.id,
          patient: null,
        });
      });
    }
  });

  return beds;
};

export function useBeds(shiftDate?: string) {
  const [beds, setBeds] = useState<Bed[]>(initializeBeds);
  const [isLoading, setIsLoading] = useState(true);
  const abortControllerRef = useRef<AbortController | null>(null);
  const loadedDateRef = useRef<string | null>(null);

  // Load beds from database on mount and when shiftDate changes
  useEffect(() => {
    const dateToLoad = shiftDate || new Date().toISOString().split('T')[0];
    
    // Avoid reloading if the date hasn't changed
    if (loadedDateRef.current === dateToLoad && !isLoading) {
      return;
    }

    // Abort previous request if still pending
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    
    abortControllerRef.current = new AbortController();

    const loadBedsFromDatabase = async () => {
      setIsLoading(true);
      
      try {
        const { data: bedRecords, error } = await supabase
          .from('bed_records')
          .select('bed_id, patient_name, hipotese_diagnostica, condutas_outros, observacao, data_nascimento, data_internacao, sus_facil, numero_sus_facil, motivo_alta, estabelecimento_transferencia')
          .eq('shift_date', dateToLoad);

        if (error) {
          console.error('Error loading bed records:', error);
          setIsLoading(false);
          return;
        }

        // Initialize all beds
        const initialBeds = initializeBeds();

        // Map database records to beds
        if (bedRecords && bedRecords.length > 0) {
          const recordsMap = new Map(bedRecords.map(r => [r.bed_id, r]));
          
          initialBeds.forEach((bed, index) => {
            const record = recordsMap.get(bed.id);
            if (record && record.patient_name) {
              initialBeds[index].patient = {
                nome: record.patient_name || '',
                hipoteseDiagnostica: record.hipotese_diagnostica || '',
                condutasOutros: record.condutas_outros || '',
                observacao: record.observacao || '',
                dataNascimento: record.data_nascimento || '',
                dataInternacao: record.data_internacao || '',
                susFacil: (record.sus_facil as 'sim' | 'nao' | '') || '',
                numeroSusFacil: record.numero_sus_facil || '',
                motivoAlta: (record.motivo_alta as Patient['motivoAlta']) || '',
                estabelecimentoTransferencia: record.estabelecimento_transferencia || '',
              };
            }
          });
        }

        loadedDateRef.current = dateToLoad;
        setBeds(initialBeds);
      } catch (err) {
        if (err instanceof Error && err.name !== 'AbortError') {
          console.error('Error loading beds:', err);
        }
      } finally {
        setIsLoading(false);
      }
    };

    loadBedsFromDatabase();

    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [shiftDate]);

  const updateBed = useCallback((bedId: string, patient: Patient | null) => {
    setBeds((prev) =>
      prev.map((bed) => (bed.id === bedId ? { ...bed, patient } : bed))
    );
  }, []);

  // Transferir paciente entre leitos do mesmo setor
  const transferPatient = useCallback((fromBed: Bed, toBed: Bed) => {
    setBeds((prev) =>
      prev.map((bed) => {
        if (bed.id === fromBed.id) {
          // O leito de origem recebe o paciente do destino (pode ser null)
          return { ...bed, patient: toBed.patient };
        }
        if (bed.id === toBed.id) {
          // O leito de destino recebe o paciente da origem
          return { ...bed, patient: fromBed.patient };
        }
        return bed;
      })
    );
  }, []);

  const getBedsBySector = useCallback(
    (sector: Sector) => {
      return beds.filter((bed) => bed.sector === sector);
    },
    [beds]
  );

  const occupancyBySector = useMemo(() => {
    const result: Record<Sector, { occupied: number; total: number }> = {} as Record<
      Sector,
      { occupied: number; total: number }
    >;

    const isCountableBed = (bed: Bed) => typeof bed.number === 'number';

    SECTORS.forEach((sector) => {
      const sectorBeds = beds.filter((bed) => bed.sector === sector.id && isCountableBed(bed));
      const occupied = sectorBeds.filter((bed) => bed.patient !== null).length;
      result[sector.id] = { occupied, total: sectorBeds.length };
    });

    return result;
  }, [beds]);

  const totalOccupancy = useMemo(() => {
    const countableBeds = beds.filter((bed) => typeof bed.number === 'number');
    const occupied = countableBeds.filter((bed) => bed.patient !== null).length;
    return { occupied, total: countableBeds.length };
  }, [beds]);

  return {
    beds,
    isLoading,
    updateBed,
    transferPatient,
    getBedsBySector,
    occupancyBySector,
    totalOccupancy,
  };
}
