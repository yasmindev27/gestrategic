import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { ShiftInfo } from '@/types/bed';

export function useShiftConfig(initialDate?: string) {
  const [shiftInfo, setShiftInfo] = useState<ShiftInfo>({
    tipo: 'diurno',
    data: initialDate || new Date().toISOString().split('T')[0],
    medicos: '',
    enfermeiros: '',
    reguladorNIR: '',
  });
  const [isLoading, setIsLoading] = useState(true);
  const previousShiftTypeRef = useRef<string>(shiftInfo.tipo);
  const previousDateRef = useRef<string>(shiftInfo.data);
  const isSavingRef = useRef(false);

  // Load shift config from database by date AND shift type
  const loadShiftConfig = useCallback(async (date: string, shiftType: 'diurno' | 'noturno') => {
    const { data, error } = await supabase
      .from('shift_configurations')
      .select('*')
      .eq('shift_date', date)
      .eq('shift_type', shiftType)
      .maybeSingle();

    if (error) {
      console.error('Error loading shift config:', error);
      return null;
    }

    return data;
  }, []);

  // Save shift config to database
  const saveShiftConfig = useCallback(async (info?: ShiftInfo) => {
    const configToSave = info || shiftInfo;
    
    if (isSavingRef.current) return;
    
    isSavingRef.current = true;
    const { error } = await supabase.from('shift_configurations').upsert({
      shift_date: configToSave.data,
      shift_type: configToSave.tipo,
      medicos: configToSave.medicos,
      enfermeiros: configToSave.enfermeiros,
      regulador_nir: configToSave.reguladorNIR,
    }, {
      onConflict: 'shift_date,shift_type'
    });

    isSavingRef.current = false;

    if (error) {
      console.error('Error saving shift config:', error);
      throw error;
    }
  }, [shiftInfo]);

  // Load config when date or shift type changes
  useEffect(() => {
    const needsReload = 
      previousShiftTypeRef.current !== shiftInfo.tipo || 
      previousDateRef.current !== shiftInfo.data;

    if (!needsReload && !isLoading) {
      return;
    }

    const loadConfig = async () => {
      setIsLoading(true);
      const config = await loadShiftConfig(shiftInfo.data, shiftInfo.tipo);
      
      if (config) {
        setShiftInfo(prev => ({
          ...prev,
          medicos: config.medicos || '',
          enfermeiros: config.enfermeiros || '',
          reguladorNIR: config.regulador_nir || '',
        }));
      } else {
        // Reset fields when no config exists for this date/type
        setShiftInfo(prev => ({
          ...prev,
          medicos: '',
          enfermeiros: '',
          reguladorNIR: '',
        }));
      }
      previousShiftTypeRef.current = shiftInfo.tipo;
      previousDateRef.current = shiftInfo.data;
      setIsLoading(false);
    };

    loadConfig();
  }, [shiftInfo.data, shiftInfo.tipo, loadShiftConfig]);

  const updateShiftInfo = useCallback((newInfo: ShiftInfo) => {
    // If shift type or date changed, reset fields and trigger reload
    if (newInfo.tipo !== previousShiftTypeRef.current || newInfo.data !== previousDateRef.current) {
      setShiftInfo({
        ...newInfo,
        medicos: '',
        enfermeiros: '',
        reguladorNIR: '',
      });
    } else {
      setShiftInfo(newInfo);
    }
  }, []);

  const fetchShiftConfigByDateAndType = useCallback(async (date: string, shiftType: 'diurno' | 'noturno') => {
    const config = await loadShiftConfig(date, shiftType);
    if (config) {
      return {
        tipo: config.shift_type as 'diurno' | 'noturno',
        data: config.shift_date,
        medicos: config.medicos || '',
        enfermeiros: config.enfermeiros || '',
        reguladorNIR: config.regulador_nir || '',
      };
    }
    return null;
  }, [loadShiftConfig]);

  return {
    shiftInfo,
    isLoading,
    updateShiftInfo,
    saveShiftConfig,
    fetchShiftConfigByDateAndType,
  };
}
