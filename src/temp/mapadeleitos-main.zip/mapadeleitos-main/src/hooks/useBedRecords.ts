import { useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Bed, ShiftInfo } from '@/types/bed';

export function useBedRecords() {
  const pendingSavesRef = useRef<Map<string, NodeJS.Timeout>>(new Map());

  const saveBedRecord = useCallback(async (bed: Bed, shiftInfo: ShiftInfo, dataAlta?: string) => {
    // Cancel any pending save for this bed
    const existingTimeout = pendingSavesRef.current.get(bed.id);
    if (existingTimeout) {
      clearTimeout(existingTimeout);
    }

    // Debounce saves to avoid excessive database writes
    return new Promise<void>((resolve) => {
      const timeout = setTimeout(async () => {
        pendingSavesRef.current.delete(bed.id);
        
        if (!bed.patient) {
          // If no patient, delete the record if it exists
          await supabase.from('bed_records').delete()
            .eq('bed_id', bed.id)
            .eq('shift_date', shiftInfo.data);
          resolve();
          return;
        }

        const { error } = await supabase.from('bed_records').upsert({
          bed_id: bed.id,
          bed_number: String(bed.number),
          sector: bed.sector,
          patient_name: bed.patient.nome,
          hipotese_diagnostica: bed.patient.hipoteseDiagnostica,
          condutas_outros: bed.patient.condutasOutros,
          observacao: bed.patient.observacao,
          data_nascimento: bed.patient.dataNascimento || null,
          data_internacao: bed.patient.dataInternacao || null,
          sus_facil: bed.patient.susFacil,
          numero_sus_facil: bed.patient.numeroSusFacil,
          motivo_alta: bed.patient.motivoAlta,
          estabelecimento_transferencia: bed.patient.estabelecimentoTransferencia,
          shift_type: shiftInfo.tipo,
          shift_date: shiftInfo.data,
          medicos: shiftInfo.medicos,
          enfermeiros: shiftInfo.enfermeiros,
          regulador_nir: shiftInfo.reguladorNIR,
          data_alta: dataAlta || bed.patient.dataAlta || null,
        }, {
          onConflict: 'bed_id,shift_date'
        });

        if (error) {
          console.error('Error saving bed record:', error);
        }
        resolve();
      }, 300);
      
      pendingSavesRef.current.set(bed.id, timeout);
    });
  }, []);

  const updateDailyStatistics = useCallback(async (
    date: string, 
    totalPatients: number, 
    patientsBySector: Record<string, number>
  ) => {
    const { error } = await supabase.from('daily_statistics').upsert({
      date,
      total_patients: totalPatients,
      patients_by_sector: patientsBySector,
    }, {
      onConflict: 'date'
    });

    if (error) {
      console.error('Error updating daily statistics:', error);
    }
  }, []);

  const fetchDailyStatistics = useCallback(async (startDate?: string, endDate?: string) => {
    let query = supabase.from('daily_statistics').select('*').order('date', { ascending: true });
    
    if (startDate) {
      query = query.gte('date', startDate);
    }
    if (endDate) {
      query = query.lte('date', endDate);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching daily statistics:', error);
      return [];
    }

    return data || [];
  }, []);

  const fetchPatientsBySector = useCallback(async (date?: string) => {
    let query = supabase.from('bed_records')
      .select('sector, patient_name')
      .not('patient_name', 'is', null);
    
    if (date) {
      query = query.eq('shift_date', date);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching patients by sector:', error);
      return {};
    }

    const result: Record<string, number> = {};
    (data || []).forEach((record) => {
      result[record.sector] = (result[record.sector] || 0) + 1;
    });

    return result;
  }, []);

  return {
    saveBedRecord,
    updateDailyStatistics,
    fetchDailyStatistics,
    fetchPatientsBySector,
  };
}
