import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface MonthlyData {
  month: string;
  monthLabel: string;
  total: number;
}

const MONTH_NAMES = [
  'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
  'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'
];

// Generate months for 2026 once
const MONTHS_2026 = Array.from({ length: 12 }, (_, month) => ({
  month: `2026-${String(month + 1).padStart(2, '0')}`,
  monthLabel: `${MONTH_NAMES[month]}/26`,
}));

export function MonthlyPatientsChart() {
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([]);
  const [currentMonthTotal, setCurrentMonthTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const isMountedRef = useRef(true);

  const fetchMonthlyData = useCallback(async () => {
    if (!isMountedRef.current) return;
    
    setLoading(true);

    // Fetch only necessary columns and filter at database level
    const { data: records, error } = await supabase
      .from('bed_records')
      .select('data_internacao, shift_date')
      .not('patient_name', 'is', null)
      .not('data_internacao', 'is', null)
      .gte('data_internacao', '2026-01-01')
      .lte('data_internacao', '2026-12-31');

    if (error) {
      console.error('Error fetching monthly data:', error);
      setLoading(false);
      return;
    }

    if (!isMountedRef.current) return;

    // Count only records where data_internacao equals shift_date (new admissions on that day)
    const monthCounts: Record<string, number> = {};
    const currentDate = new Date();
    const currentMonth = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;

    (records || []).forEach((record) => {
      // Only count if the admission date matches the shift date (new admission)
      if (record.data_internacao === record.shift_date) {
        const date = new Date(record.data_internacao);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        monthCounts[monthKey] = (monthCounts[monthKey] || 0) + 1;
      }
    });

    // Map to chart data
    const chartData: MonthlyData[] = MONTHS_2026.map(({ month, monthLabel }) => ({
      month,
      monthLabel,
      total: monthCounts[month] || 0,
    }));

    setMonthlyData(chartData);
    setCurrentMonthTotal(monthCounts[currentMonth] || 0);
    setLoading(false);
  }, []);

  useEffect(() => {
    isMountedRef.current = true;
    fetchMonthlyData();

    // Set up realtime subscription
    channelRef.current = supabase
      .channel('monthly-stats')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bed_records',
        },
        () => {
          // Debounce realtime updates
          setTimeout(() => {
            if (isMountedRef.current) {
              fetchMonthlyData();
            }
          }, 500);
        }
      )
      .subscribe();

    return () => {
      isMountedRef.current = false;
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
      }
    };
  }, [fetchMonthlyData]);

  const hasData = useMemo(() => monthlyData.some(d => d.total > 0), [monthlyData]);

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-48">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Users className="h-5 w-5 text-primary" />
            Internações por Mês
          </CardTitle>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Este mês</p>
            <p className="text-2xl font-bold text-primary">{currentMonthTotal}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {!hasData ? (
          <div className="flex items-center justify-center h-48 text-muted-foreground">
            Nenhum dado de internação disponível
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" vertical={false} />
              <XAxis
                dataKey="monthLabel"
                tick={{ fill: 'hsl(var(--foreground))', fontSize: 11 }}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                tick={{ fill: 'hsl(var(--foreground))', fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                allowDecimals={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
                labelStyle={{ color: 'hsl(var(--foreground))' }}
                formatter={(value: number) => [`${value} internações`, 'Total']}
              />
              <Bar
                dataKey="total"
                fill="hsl(var(--primary))"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}
