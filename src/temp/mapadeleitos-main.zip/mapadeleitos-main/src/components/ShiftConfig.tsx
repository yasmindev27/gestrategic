import { useState } from 'react';
import { Sun, Moon, Calendar, Stethoscope, Users, UserCheck, Save, Check } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { ShiftInfo } from '@/types/bed';
import { toast } from 'sonner';

interface ShiftConfigProps {
  shiftInfo: ShiftInfo;
  onShiftInfoChange: (info: ShiftInfo) => void;
  onSave?: () => Promise<void>;
}

export function ShiftConfig({ shiftInfo, onShiftInfoChange, onSave }: ShiftConfigProps) {
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleChange = (field: keyof ShiftInfo, value: string) => {
    setSaved(false);
    onShiftInfoChange({ ...shiftInfo, [field]: value });
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      if (onSave) {
        await onSave();
      }
      setSaved(true);
      toast.success('Configuração do plantão salva com sucesso!');
      setTimeout(() => setSaved(false), 3000);
    } catch (error) {
      toast.error('Erro ao salvar configuração');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="info-card animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" />
          Configuração do Plantão
        </h2>
        <Button 
          onClick={handleSave} 
          disabled={isSaving}
          className="gap-2"
          variant={saved ? "outline" : "default"}
        >
          {isSaving ? (
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
          ) : saved ? (
            <Check className="w-4 h-4 text-hospital-green" />
          ) : (
            <Save className="w-4 h-4" />
          )}
          {saved ? 'Salvo' : 'Salvar Plantão'}
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Tipo de Plantão */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">Tipo de Plantão</Label>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => handleChange('tipo', 'diurno')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-all duration-200 ${
                shiftInfo.tipo === 'diurno'
                  ? 'bg-hospital-amber/10 border-hospital-amber text-hospital-amber'
                  : 'bg-secondary border-transparent hover:border-hospital-amber/50'
              }`}
            >
              <Sun className="w-5 h-5" />
              <span className="font-medium">Diurno</span>
            </button>
            <button
              type="button"
              onClick={() => handleChange('tipo', 'noturno')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-all duration-200 ${
                shiftInfo.tipo === 'noturno'
                  ? 'bg-primary/10 border-primary text-primary'
                  : 'bg-secondary border-transparent hover:border-primary/50'
              }`}
            >
              <Moon className="w-5 h-5" />
              <span className="font-medium">Noturno</span>
            </button>
          </div>
        </div>

        {/* Data do Plantão */}
        <div className="space-y-2">
          <Label htmlFor="data" className="text-sm font-medium flex items-center gap-2">
            <Calendar className="w-4 h-4 text-muted-foreground" />
            Data do Plantão
          </Label>
          <Input
            id="data"
            type="date"
            value={shiftInfo.data}
            onChange={(e) => handleChange('data', e.target.value)}
            className="bg-background"
          />
        </div>

        {/* Regulador NIR */}
        <div className="space-y-2">
          <Label htmlFor="regulador" className="text-sm font-medium flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-muted-foreground" />
            Regulador do NIR
          </Label>
          <Input
            id="regulador"
            type="text"
            placeholder="Nome do regulador"
            value={shiftInfo.reguladorNIR}
            onChange={(e) => handleChange('reguladorNIR', e.target.value)}
            className="bg-background"
          />
        </div>

        {/* Médicos */}
        <div className="space-y-2 md:col-span-1 lg:col-span-1">
          <Label htmlFor="medicos" className="text-sm font-medium flex items-center gap-2">
            <Stethoscope className="w-4 h-4 text-muted-foreground" />
            Médicos do Plantão
          </Label>
          <Textarea
            id="medicos"
            placeholder="Ex: Dr. João, Dra. Maria..."
            value={shiftInfo.medicos}
            onChange={(e) => handleChange('medicos', e.target.value)}
            className="bg-background min-h-[80px] resize-none"
          />
        </div>

        {/* Enfermeiros */}
        <div className="space-y-2 md:col-span-1 lg:col-span-2">
          <Label htmlFor="enfermeiros" className="text-sm font-medium flex items-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            Enfermeiros do Plantão
          </Label>
          <Textarea
            id="enfermeiros"
            placeholder="Ex: Enf. Pedro, Enf. Ana..."
            value={shiftInfo.enfermeiros}
            onChange={(e) => handleChange('enfermeiros', e.target.value)}
            className="bg-background min-h-[80px] resize-none"
          />
        </div>
      </div>
    </div>
  );
}
