import { useState, useEffect, useMemo } from 'react';
import { X, Save, Trash2, ArrowRightLeft } from 'lucide-react';
import { differenceInYears } from 'date-fns';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { HospitalizationDaysChart } from '@/components/HospitalizationDaysChart';
import { Bed, Patient, MotivoAlta } from '@/types/bed';

interface BedModalProps {
  bed: Bed | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (bed: Bed, patient: Patient | null, isDischarge?: boolean) => void;
  sectorBeds?: Bed[];
  onTransfer?: (fromBed: Bed, toBed: Bed) => void;
}

const emptyPatient: Patient = {
  nome: '',
  hipoteseDiagnostica: '',
  condutasOutros: '',
  observacao: '',
  dataNascimento: '',
  dataInternacao: '',
  susFacil: '',
  numeroSusFacil: '',
  motivoAlta: '',
  estabelecimentoTransferencia: '',
};

export function BedModal({ bed, isOpen, onClose, onSave, sectorBeds = [], onTransfer }: BedModalProps) {
  const [patient, setPatient] = useState<Patient>(emptyPatient);
  const [selectedTransferBed, setSelectedTransferBed] = useState<string>('');

  useEffect(() => {
    if (bed?.patient) {
      setPatient(bed.patient);
    } else {
      setPatient(emptyPatient);
    }
    setSelectedTransferBed('');
  }, [bed]);

  const calculatedAge = useMemo(() => {
    if (!patient.dataNascimento) return null;
    const birthDate = new Date(patient.dataNascimento);
    const today = new Date();
    return differenceInYears(today, birthDate);
  }, [patient.dataNascimento]);

  const handleChange = (field: keyof Patient, value: string) => {
    setPatient((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    if (!bed) return;
    
    // Validate establishment name if transfer is selected
    if (patient.motivoAlta === 'transferencia' && patient.estabelecimentoTransferencia.trim() === '') {
      return;
    }
    
    const hasData = patient.nome.trim() !== '';
    
    onSave(bed, hasData ? patient : null);
    onClose();
  };

  // Função para registrar alta e liberar leito automaticamente
  const handleDischarge = () => {
    if (!bed) return;
    
    // Validate establishment name if transfer is selected
    if (patient.motivoAlta === 'transferencia' && patient.estabelecimentoTransferencia.trim() === '') {
      return;
    }
    
    if (!patient.motivoAlta) {
      return; // Não pode dar alta sem motivo
    }
    
    // Registra a data/hora da alta e libera o leito
    const patientWithDischargeDate: Patient = {
      ...patient,
      dataAlta: new Date().toISOString(),
    };
    
    // Salva os dados com a data da alta antes de liberar
    onSave(bed, patientWithDischargeDate, true); // true indica que é uma alta
    onClose();
  };

  const canDischarge = patient.motivoAlta && (patient.motivoAlta !== 'transferencia' || patient.estabelecimentoTransferencia.trim() !== '');

  // Leitos disponíveis para transferência (vazios ou com pacientes, exceto o atual)
  const availableBedsForTransfer = sectorBeds.filter(b => b.id !== bed?.id);

  const handleTransfer = () => {
    if (!bed || !selectedTransferBed || !onTransfer) return;
    
    const targetBed = sectorBeds.find(b => b.id === selectedTransferBed);
    if (!targetBed) return;

    onTransfer(bed, targetBed);
    setSelectedTransferBed('');
    onClose();
  };

  const getBedDisplayLabel = (bedItem: Bed) => {
    if (bedItem.number === 'EXTRA' || bedItem.number === 'MACA EXTRA' || bedItem.number === 'MACA PCR') {
      return String(bedItem.number);
    }
    return `Leito ${String(bedItem.number).padStart(2, '0')}`;
  };

  if (!bed) return null;

  const getBedLabel = () => {
    if (bed.number === 'EXTRA') return 'EXTRA';
    return String(bed.number).padStart(2, '0');
  };

  const getSectorName = () => {
    const names: Record<string, string> = {
      'enfermaria-masculina': 'Enfermaria Masculina',
      'enfermaria-feminina': 'Enfermaria Feminina',
      'pediatria': 'Pediatria',
      'isolamento': 'Isolamento',
      'urgencia': 'Urgência',
      'medicacao': 'Medicação',
    };
    return names[bed.sector] || bed.sector;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <span className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 text-primary font-bold">
              {getBedLabel()}
            </span>
            <div>
              <div className="font-bold">Leito {getBedLabel()}</div>
              <div className="text-sm font-normal text-muted-foreground">{getSectorName()}</div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-4">
          {/* Nome do Paciente */}
          <div className="space-y-2">
            <Label htmlFor="nome" className="text-sm font-medium">
              Nome do Paciente <span className="text-destructive">*</span>
            </Label>
            <Input
              id="nome"
              placeholder="Digite o nome completo do paciente"
              value={patient.nome}
              onChange={(e) => handleChange('nome', e.target.value)}
              className="bg-background"
            />
          </div>

          {/* Data de Nascimento e Idade */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dataNascimento" className="text-sm font-medium">
                Data de Nascimento
              </Label>
              <Input
                id="dataNascimento"
                type="date"
                value={patient.dataNascimento}
                onChange={(e) => handleChange('dataNascimento', e.target.value)}
                className="bg-background"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">Idade</Label>
              <div className="h-10 px-3 flex items-center rounded-md border bg-muted/50 text-foreground">
                {calculatedAge !== null ? `${calculatedAge} anos` : '-'}
              </div>
            </div>
          </div>

          {/* Data da Internação e Dias de Internação */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dataInternacao" className="text-sm font-medium">
                Data da Internação
              </Label>
              <Input
                id="dataInternacao"
                type="date"
                value={patient.dataInternacao}
                onChange={(e) => handleChange('dataInternacao', e.target.value)}
                className="bg-background"
              />
            </div>
            {patient.dataInternacao && (
              <HospitalizationDaysChart dataInternacao={patient.dataInternacao} />
            )}
          </div>

          {/* Nº SUSFÁCIL */}
          <div className="space-y-2">
            <Label htmlFor="numeroSusFacil" className="text-sm font-medium">
              Nº SUSFÁCIL
            </Label>
            <Input
              id="numeroSusFacil"
              placeholder="Digite o número do SUSFÁCIL"
              value={patient.numeroSusFacil}
              onChange={(e) => handleChange('numeroSusFacil', e.target.value)}
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="hipotese" className="text-sm font-medium">
              Hipótese Diagnóstica (HD)
            </Label>
            <Textarea
              id="hipotese"
              placeholder="Descreva a hipótese diagnóstica"
              value={patient.hipoteseDiagnostica}
              onChange={(e) => handleChange('hipoteseDiagnostica', e.target.value)}
              className="bg-background min-h-[80px] resize-none"
            />
          </div>

          {/* Condutas/Outros */}
          <div className="space-y-2">
            <Label htmlFor="condutas" className="text-sm font-medium">
              Condutas / Outros
            </Label>
            <Textarea
              id="condutas"
              placeholder="Descreva as condutas e outras informações"
              value={patient.condutasOutros}
              onChange={(e) => handleChange('condutasOutros', e.target.value)}
              className="bg-background min-h-[80px] resize-none"
            />
          </div>

          {/* Observação */}
          <div className="space-y-2">
            <Label htmlFor="observacao" className="text-sm font-medium">
              Observação
            </Label>
            <Textarea
              id="observacao"
              placeholder="Observações adicionais"
              value={patient.observacao}
              onChange={(e) => handleChange('observacao', e.target.value)}
              className="bg-background min-h-[60px] resize-none"
            />
          </div>

          {/* SUS Fácil */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">SUS Fácil?</Label>
            <RadioGroup
              value={patient.susFacil}
              onValueChange={(value) => handleChange('susFacil', value as 'sim' | 'nao')}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="sim" id="sus-sim" />
                <Label htmlFor="sus-sim" className="cursor-pointer font-normal">
                  Sim
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="nao" id="sus-nao" />
                <Label htmlFor="sus-nao" className="cursor-pointer font-normal">
                  Não
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Trocar de Leito */}
          {bed.patient && onTransfer && availableBedsForTransfer.length > 0 && (
            <div className="space-y-2 p-4 rounded-lg border border-primary/20 bg-primary/5">
              <Label className="text-sm font-medium flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4" />
                Trocar de Leito (mesmo setor)
              </Label>
              <div className="flex gap-2">
                <Select
                  value={selectedTransferBed}
                  onValueChange={setSelectedTransferBed}
                >
                  <SelectTrigger className="bg-background flex-1">
                    <SelectValue placeholder="Selecione o leito de destino" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableBedsForTransfer.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {getBedDisplayLabel(b)} {b.patient ? `(${b.patient.nome.split(' ')[0]})` : '(Vazio)'}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  variant="secondary"
                  onClick={handleTransfer}
                  disabled={!selectedTransferBed}
                  className="gap-2"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                  Trocar
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Se o leito de destino estiver ocupado, os pacientes serão trocados de lugar.
              </p>
            </div>
          )}

          {/* Motivo da Alta */}
          <div className="space-y-2">
            <Label htmlFor="motivoAlta" className="text-sm font-medium">
              Motivo da Alta
            </Label>
            <Select
              value={patient.motivoAlta}
              onValueChange={(value) => {
                handleChange('motivoAlta', value as MotivoAlta);
                if (value !== 'transferencia') {
                  handleChange('estabelecimentoTransferencia', '');
                }
              }}
            >
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Selecione o motivo da alta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="alta-melhorada">Alta Melhorada</SelectItem>
                <SelectItem value="evasao">Evasão</SelectItem>
                <SelectItem value="transferencia">Transferência</SelectItem>
                <SelectItem value="obito">Óbito</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Nome do Estabelecimento (apenas para transferência) */}
          {patient.motivoAlta === 'transferencia' && (
            <div className="space-y-2">
              <Label htmlFor="estabelecimento" className="text-sm font-medium">
                Nome do Estabelecimento <span className="text-destructive">*</span>
              </Label>
              <Input
                id="estabelecimento"
                placeholder="Digite o nome do estabelecimento de destino"
                value={patient.estabelecimentoTransferencia}
                onChange={(e) => handleChange('estabelecimentoTransferencia', e.target.value)}
                className="bg-background"
                required
              />
            </div>
          )}
        </div>

        <div className="flex items-center justify-between gap-3 pt-4 border-t">
          {bed.patient && patient.motivoAlta && (
            <Button
              type="button"
              variant="destructive"
              onClick={handleDischarge}
              disabled={!canDischarge}
              className="gap-2"
              title={!canDischarge ? 'Selecione um motivo de alta válido' : 'Dar alta e liberar o leito'}
            >
              <Trash2 className="w-4 h-4" />
              Dar Alta e Liberar Leito
            </Button>
          )}
          <div className="flex gap-3 ml-auto">
            <Button type="button" variant="outline" onClick={onClose}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="button" onClick={handleSave} className="gap-2">
              <Save className="w-4 h-4" />
              Salvar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
