import { useRef } from 'react';
import { FileDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import html2pdf from 'html2pdf.js';
const SECTOR_NAMES: Record<string, string> = {
  'enfermaria-masculina': 'Enf. Masculina',
  'enfermaria-feminina': 'Enf. Feminina',
  'pediatria': 'Pediatria',
  'isolamento': 'Isolamento',
  'urgencia': 'Urgência'
};
const MOTIVO_ALTA_NAMES: Record<string, string> = {
  'alta-melhorada': 'Alta Melhorada',
  'evasao': 'Evasão',
  'transferencia': 'Transferência',
  'obito': 'Óbito',
  '': '-'
};
interface BedRecord {
  id: string;
  bed_number: string;
  sector: string;
  patient_name: string | null;
  hipotese_diagnostica: string | null;
  condutas_outros: string | null;
  observacao: string | null;
  data_nascimento: string | null;
  data_internacao: string | null;
  sus_facil: string | null;
  numero_sus_facil: string | null;
  motivo_alta: string | null;
  estabelecimento_transferencia: string | null;
  shift_date: string;
  shift_type: string;
  medicos: string | null;
  enfermeiros: string | null;
  data_alta: string | null;
}
interface ShiftConfig {
  tipo: 'diurno' | 'noturno';
  medicos: string;
  enfermeiros: string;
  reguladorNIR: string;
}
interface BedRecordsTableProps {
  records: BedRecord[];
  selectedDate: string;
  shiftConfigDiurno?: ShiftConfig | null;
  shiftConfigNoturno?: ShiftConfig | null;
}
const calculateAge = (birthDate: string | null): string => {
  if (!birthDate) return '-';
  const birth = new Date(birthDate);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || monthDiff === 0 && today.getDate() < birth.getDate()) {
    age--;
  }
  return `${age} anos`;
};
const calculateHospitalizationDays = (admissionDate: string | null): string => {
  if (!admissionDate) return '-';
  const admission = new Date(admissionDate);
  const today = new Date();
  const diffTime = Math.abs(today.getTime() - admission.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return `${diffDays} dias`;
};
const formatDate = (date: string | null): string => {
  if (!date) return '-';
  // Add T12:00:00 to avoid timezone issues
  return new Date(date + 'T12:00:00').toLocaleDateString('pt-BR');
};

const formatDateTime = (dateTime: string | null): string => {
  if (!dateTime) return '';
  const date = new Date(dateTime);
  return `${date.toLocaleDateString('pt-BR')} ${date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
};
const BedRecordsTable = ({
  records,
  selectedDate,
  shiftConfigDiurno,
  shiftConfigNoturno
}: BedRecordsTableProps) => {
  const tableRef = useRef<HTMLDivElement>(null);
  const exportToPDF = () => {
    if (!tableRef.current) return;
    const element = tableRef.current;
    const opt = {
      margin: [10, 5, 10, 5],
      filename: `relatorio-leitos-${selectedDate}.pdf`,
      image: {
        type: 'jpeg',
        quality: 0.98
      },
      html2canvas: {
        scale: 2,
        useCORS: true
      },
      jsPDF: {
        unit: 'mm',
        format: 'a4',
        orientation: 'landscape'
      }
    };
    html2pdf().set(opt).from(element).save();
  };
  const occupiedRecords = records.filter(r => r.patient_name);
  return <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">
          Registros de Leitos - {new Date(selectedDate + 'T12:00:00').toLocaleDateString('pt-BR')}
        </h3>
        <Button onClick={exportToPDF} variant="outline" className="gap-2">
          <FileDown className="h-4 w-4" />
          Exportar PDF
        </Button>
      </div>

      <div ref={tableRef} className="bg-card p-4 rounded-lg">
        {/* Report Header with Shift Info */}
        <div className="mb-6 border-b pb-4">
          <h2 className="text-xl font-bold text-center mb-3">Relatório de Leitos</h2>
          <p className="text-center text-muted-foreground mb-4">
            Data: {new Date(selectedDate + 'T12:00:00').toLocaleDateString('pt-BR')}
          </p>
          
          {/* Diurno Shift */}
          <div className="mb-4 p-3 bg-muted/30 rounded-lg">
            <h3 className="font-semibold text-primary mb-2">Plantão Diurno (07:00 as 19:00)</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
              <div>
                <span className="font-medium text-muted-foreground">Médicos:</span>{' '}
                <span>{shiftConfigDiurno?.medicos || '-'}</span>
              </div>
              <div>
                <span className="font-medium text-muted-foreground">Enfermeiros:</span>{' '}
                <span>{shiftConfigDiurno?.enfermeiros || '-'}</span>
              </div>
              <div>
                <span className="font-medium text-muted-foreground">Regulador NIR:</span>{' '}
                <span>{shiftConfigDiurno?.reguladorNIR || '-'}</span>
              </div>
            </div>
          </div>

          {/* Noturno Shift */}
          <div className="mb-4 p-3 bg-muted/30 rounded-lg">
            <h3 className="font-semibold text-primary mb-2">Plantão Noturno (19:00 as 07:00)</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
              <div>
                <span className="font-medium text-muted-foreground">Médicos:</span>{' '}
                <span>{shiftConfigNoturno?.medicos || '-'}</span>
              </div>
              <div>
                <span className="font-medium text-muted-foreground">Enfermeiros:</span>{' '}
                <span>{shiftConfigNoturno?.enfermeiros || '-'}</span>
              </div>
              <div>
                <span className="font-medium text-muted-foreground">Regulador NIR:</span>{' '}
                <span>{shiftConfigNoturno?.reguladorNIR || '-'}</span>
              </div>
            </div>
          </div>

          <div className="text-center">
            <span className="font-semibold text-muted-foreground">Total de Pacientes:</span>{' '}
            <span className="text-xl font-bold text-primary">{occupiedRecords.length}</span>
          </div>
        </div>

        {occupiedRecords.length === 0 ? <div className="text-center py-8 text-muted-foreground">
            Nenhum registro encontrado para esta data
          </div> : <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Leito</TableHead>
                  <TableHead className="whitespace-nowrap">Setor</TableHead>
                  <TableHead className="whitespace-nowrap">Paciente</TableHead>
                  <TableHead className="whitespace-nowrap">Idade</TableHead>
                  <TableHead className="whitespace-nowrap">Data Nasc.</TableHead>
                  <TableHead className="whitespace-nowrap">Data Int.</TableHead>
                  <TableHead className="whitespace-nowrap">Dias Int.</TableHead>
                  <TableHead className="whitespace-nowrap">Hipótese Diagnóstica</TableHead>
                  <TableHead className="whitespace-nowrap">Nº SUSFÁCIL</TableHead>
                  <TableHead className="whitespace-nowrap">Motivo Alta</TableHead>
                  <TableHead className="whitespace-nowrap">Observação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {occupiedRecords.map(record => <TableRow key={record.id}>
                    <TableCell className="font-medium">{record.bed_number}</TableCell>
                    <TableCell>{SECTOR_NAMES[record.sector] || record.sector}</TableCell>
                    <TableCell>{record.patient_name || '-'}</TableCell>
                    <TableCell>{calculateAge(record.data_nascimento)}</TableCell>
                    <TableCell>{formatDate(record.data_nascimento)}</TableCell>
                    <TableCell>{formatDate(record.data_internacao)}</TableCell>
                    <TableCell>{calculateHospitalizationDays(record.data_internacao)}</TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {record.hipotese_diagnostica || '-'}
                    </TableCell>
                    <TableCell>{record.numero_sus_facil || '-'}</TableCell>
                    <TableCell>
                      {record.motivo_alta 
                        ? `${MOTIVO_ALTA_NAMES[record.motivo_alta] || record.motivo_alta}${record.data_alta ? ` - ${formatDateTime(record.data_alta)}` : ''}`
                        : '-'}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {record.observacao || '-'}
                    </TableCell>
                  </TableRow>)}
              </TableBody>
            </Table>
          </div>}
      </div>
    </div>;
};
export default BedRecordsTable;