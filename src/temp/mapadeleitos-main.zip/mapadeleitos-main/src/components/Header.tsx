import { Activity } from 'lucide-react';

interface HeaderProps {
  shiftType: 'noturno' | 'diurno';
  shiftDate: string;
}

export function Header({ shiftType, shiftDate }: HeaderProps) {
  const formattedDate = shiftDate 
    ? new Date(shiftDate + 'T00:00:00').toLocaleDateString('pt-BR', { 
        weekday: 'long', 
        day: '2-digit', 
        month: 'long', 
        year: 'numeric' 
      })
    : '';

  return (
    <header className="header-gradient text-primary-foreground shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary-foreground/20 rounded-xl">
              <Activity className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
                UP24h - Controle de Leitos
              </h1>
              <p className="text-primary-foreground/80 text-sm mt-1">
                Sistema de Gestão de Ocupação Hospitalar
              </p>
            </div>
          </div>
          
          {shiftDate && (
            <div className="flex flex-col items-start md:items-end gap-1">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-primary-foreground/20">
                {shiftType === 'noturno' ? '🌙 Plantão Noturno' : '☀️ Plantão Diurno'}
              </span>
              <span className="text-primary-foreground/90 text-sm capitalize">
                {formattedDate}
              </span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
