import { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, startOfYear, endOfYear } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

export type PeriodType = 'daily' | 'monthly' | 'yearly';

interface PeriodSelectorProps {
  onPeriodChange: (startDate: string, endDate: string, periodType: PeriodType) => void;
  showDaily?: boolean;
}

export const PeriodSelector = ({ onPeriodChange, showDaily = true }: PeriodSelectorProps) => {
  const today = new Date();
  const [periodType, setPeriodType] = useState<PeriodType>(showDaily ? 'daily' : 'monthly');
  const [selectedDate, setSelectedDate] = useState(format(today, 'yyyy-MM-dd'));
  const [selectedMonth, setSelectedMonth] = useState(format(today, 'yyyy-MM'));
  const [selectedYear, setSelectedYear] = useState(format(today, 'yyyy'));

  useEffect(() => {
    let startDate: string;
    let endDate: string;

    switch (periodType) {
      case 'daily':
        startDate = selectedDate;
        endDate = selectedDate;
        break;
      case 'monthly':
        const [year, month] = selectedMonth.split('-').map(Number);
        const monthDate = new Date(year, month - 1, 1);
        startDate = format(startOfMonth(monthDate), 'yyyy-MM-dd');
        endDate = format(endOfMonth(monthDate), 'yyyy-MM-dd');
        break;
      case 'yearly':
        const yearDate = new Date(parseInt(selectedYear), 0, 1);
        startDate = format(startOfYear(yearDate), 'yyyy-MM-dd');
        endDate = format(endOfYear(yearDate), 'yyyy-MM-dd');
        break;
    }

    onPeriodChange(startDate, endDate, periodType);
  }, [periodType, selectedDate, selectedMonth, selectedYear, onPeriodChange]);

  const getPeriodLabel = () => {
    switch (periodType) {
      case 'daily':
        return format(new Date(selectedDate), "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR });
      case 'monthly':
        const monthDate = new Date(selectedMonth + '-01');
        return format(monthDate, "MMMM 'de' yyyy", { locale: ptBR });
      case 'yearly':
        return `Ano de ${selectedYear}`;
    }
  };

  // Generate year options (last 5 years)
  const yearOptions = Array.from({ length: 5 }, (_, i) => {
    const year = today.getFullYear() - i;
    return year.toString();
  });

  return (
    <div className="space-y-4">
      <Tabs value={periodType} onValueChange={(v) => setPeriodType(v as PeriodType)}>
        <TabsList className="grid w-full max-w-md" style={{ gridTemplateColumns: showDaily ? 'repeat(3, 1fr)' : 'repeat(2, 1fr)' }}>
          {showDaily && <TabsTrigger value="daily">Diário</TabsTrigger>}
          <TabsTrigger value="monthly">Mensal</TabsTrigger>
          <TabsTrigger value="yearly">Anual</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="flex flex-wrap items-end gap-4">
        {periodType === 'daily' && (
          <div className="space-y-2">
            <Label htmlFor="date">Data</Label>
            <Input
              id="date"
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-48"
            />
          </div>
        )}

        {periodType === 'monthly' && (
          <div className="space-y-2">
            <Label htmlFor="month">Mês</Label>
            <Input
              id="month"
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-48"
            />
          </div>
        )}

        {periodType === 'yearly' && (
          <div className="space-y-2">
            <Label htmlFor="year">Ano</Label>
            <select
              id="year"
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="flex h-10 w-32 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              {yearOptions.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        )}

        <div className="text-sm text-muted-foreground pb-2">
          {getPeriodLabel()}
        </div>
      </div>
    </div>
  );
};
