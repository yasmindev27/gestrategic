import { forwardRef, memo } from 'react';
import { User, AlertCircle } from 'lucide-react';
import { Bed } from '@/types/bed';

interface BedCardProps {
  bed: Bed;
  onClick: () => void;
}

export const BedCard = memo(forwardRef<HTMLDivElement, BedCardProps>(
  function BedCard({ bed, onClick }, ref) {
    const isOccupied = bed.patient !== null;
    const isExtra = typeof bed.number === 'string';

    const getCardClass = () => {
      if (isExtra) return 'leito-card leito-extra';
      if (isOccupied) return 'leito-card leito-occupied';
      return 'leito-card leito-empty';
    };

    const getBedLabel = () => {
      if (typeof bed.number === 'string') return bed.number;
      return String(bed.number).padStart(2, '0');
    };

    return (
      <div 
        ref={ref}
        className={`${getCardClass()} animate-scale-in cursor-pointer`} 
        onClick={onClick}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onClick();
          }
        }}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className={`text-lg font-bold ${
              isOccupied ? 'text-hospital-green' : isExtra ? 'text-hospital-amber' : 'text-muted-foreground'
            }`}>
              LEITO {getBedLabel()}
            </span>
          </div>
          <div className={`p-2 rounded-lg ${
            isOccupied 
              ? 'bg-hospital-green/20 text-hospital-green' 
              : 'bg-muted text-muted-foreground'
          }`}>
            {isOccupied ? <User className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          </div>
        </div>

        {isOccupied && bed.patient ? (
          <div className="space-y-2">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Paciente</p>
              <p className="font-semibold text-foreground truncate">{bed.patient.nome}</p>
            </div>
            
            {bed.patient.hipoteseDiagnostica && (
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">HD</p>
                <p className="text-sm text-foreground line-clamp-2">{bed.patient.hipoteseDiagnostica}</p>
              </div>
            )}

            <div className="flex items-center gap-2 pt-2">
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                bed.patient.susFacil === 'sim' 
                  ? 'bg-hospital-green/20 text-hospital-green' 
                  : 'bg-muted text-muted-foreground'
              }`}>
                SUS Fácil: {bed.patient.susFacil === 'sim' ? 'Sim' : 'Não'}
              </span>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center py-4">
            <span className="text-muted-foreground text-sm">Leito disponível</span>
          </div>
        )}

        <div className="mt-3 pt-3 border-t border-border">
          <span className="text-xs text-primary font-medium hover:underline">
            Clique para {isOccupied ? 'editar' : 'cadastrar'}
          </span>
        </div>
      </div>
    );
  }
));
