import { useMemo } from 'react';
import { differenceInDays } from 'date-fns';

interface HospitalizationDaysChartProps {
  dataInternacao: string;
}

export function HospitalizationDaysChart({ dataInternacao }: HospitalizationDaysChartProps) {
  const { days, percentage, strokeDasharray, strokeDashoffset } = useMemo(() => {
    if (!dataInternacao) {
      return { days: 0, percentage: 0, strokeDasharray: 0, strokeDashoffset: 0 };
    }

    const startDate = new Date(dataInternacao);
    const today = new Date();
    const diffDays = differenceInDays(today, startDate);
    const daysCount = Math.max(0, diffDays);
    
    // Max days for the chart visualization (30 days = full circle)
    const maxDays = 30;
    const pct = Math.min((daysCount / maxDays) * 100, 100);
    
    // Circle calculations
    const radius = 40;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (pct / 100) * circumference;
    
    return { 
      days: daysCount, 
      percentage: pct, 
      strokeDasharray: circumference, 
      strokeDashoffset: offset 
    };
  }, [dataInternacao]);

  if (!dataInternacao) {
    return null;
  }

  return (
    <div className="flex flex-col items-center justify-center p-4 bg-muted/30 rounded-lg">
      <span className="text-sm font-medium text-muted-foreground mb-2">Dias de Internação</span>
      <div className="relative w-24 h-24">
        <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
          {/* Background circle */}
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke="hsl(var(--muted))"
            strokeWidth="8"
          />
          {/* Progress circle */}
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke="hsl(var(--primary))"
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={strokeDasharray}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-500 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-foreground">{days}</span>
          <span className="text-xs text-muted-foreground">
            {days === 1 ? 'dia' : 'dias'}
          </span>
        </div>
      </div>
    </div>
  );
}
