import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ArrowLeft, FileText, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import html2pdf from 'html2pdf.js';
import { PeriodSelector, PeriodType } from '@/components/PeriodSelector';

const MOTIVO_ALTA_NAMES: Record<string, string> = {
  'alta-melhorada': 'Alta Melhorada',
  'evasao': 'Evasão',
  'transferencia': 'Transferência',
  'obito': 'Óbito',
};

const SECTOR_NAMES: Record<string, string> = {
  'enfermaria-masculina': 'Enfermaria Masculina',
  'enfermaria-feminina': 'Enfermaria Feminina',
  'pediatria': 'Pediatria',
  'isolamento': 'Isolamento',
  'urgencia': 'Urgência',
};

interface DischargeRecord {
  id: string;
  bed_number: string;
  sector: string;
  patient_name: string;
  data_internacao: string | null;
  data_alta: string | null;
  motivo_alta: string;
  estabelecimento_transferencia: string | null;
  numero_sus_facil: string | null;
}

const DischargeReport = () => {
  const navigate = useNavigate();
  const [startDate, setStartDate] = useState(() => format(new Date(), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(() => format(new Date(), 'yyyy-MM-dd'));
  const [periodType, setPeriodType] = useState<PeriodType>('monthly');
  const [records, setRecords] = useState<DischargeRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const handlePeriodChange = useCallback((start: string, end: string, type: PeriodType) => {
    setStartDate(start);
    setEndDate(end);
    setPeriodType(type);
  }, []);

  const fetchDischargeRecords = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('bed_records')
        .select('id, bed_number, sector, patient_name, data_internacao, data_alta, motivo_alta, estabelecimento_transferencia, numero_sus_facil')
        .not('motivo_alta', 'is', null)
        .neq('motivo_alta', '')
        .gte('shift_date', startDate)
        .lte('shift_date', endDate)
        .order('data_alta', { ascending: false });

      if (error) {
        console.error('Error fetching discharge records:', error);
        return;
      }

      setRecords(data || []);
    } catch (err) {
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate]);

  useEffect(() => {
    fetchDischargeRecords();
  }, [fetchDischargeRecords]);

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('discharge-records-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bed_records',
        },
        () => {
          fetchDischargeRecords();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchDischargeRecords]);

  const exportToPDF = async () => {
    if (!reportRef.current || records.length === 0) return;
    
    setExporting(true);
    try {
      const element = reportRef.current;
      const periodLabel = periodType === 'daily' ? startDate : 
                         periodType === 'monthly' ? format(parseISO(startDate), 'yyyy-MM') : 
                         format(parseISO(startDate), 'yyyy');
      const opt = {
        margin: [10, 10, 10, 10],
        filename: `relatorio-altas-${periodLabel}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
      };
      
      await html2pdf().set(opt).from(element).save();
    } catch (error) {
      console.error('Erro ao exportar PDF:', error);
    } finally {
      setExporting(false);
    }
  };

  const getPeriodTitle = () => {
    switch (periodType) {
      case 'daily':
        return format(parseISO(startDate), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
      case 'monthly':
        return format(parseISO(startDate), "MMMM 'de' yyyy", { locale: ptBR });
      case 'yearly':
        return `Ano de ${format(parseISO(startDate), 'yyyy')}`;
    }
  };

  const groupedRecords = records.reduce((acc, record) => {
    const motivo = record.motivo_alta;
    if (!acc[motivo]) {
      acc[motivo] = [];
    }
    acc[motivo].push(record);
    return acc;
  }, {} as Record<string, DischargeRecord[]>);

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '-';
    try {
      return format(parseISO(dateStr), 'dd/MM/yyyy', { locale: ptBR });
    } catch {
      return '-';
    }
  };

  const formatDateTime = (dateStr: string | null) => {
    if (!dateStr) return '-';
    try {
      return format(parseISO(dateStr), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });
    } catch {
      return '-';
    }
  };

  const totalDischarges = records.length;

  return (
    <div className="min-h-screen bg-background p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <FileText className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">Relatório de Altas</h1>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Período de Consulta</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
              <PeriodSelector onPeriodChange={handlePeriodChange} showDaily={false} />
              <Button 
                onClick={exportToPDF} 
                disabled={exporting || records.length === 0}
                className="gap-2 self-start lg:self-auto"
              >
                <Download className="h-4 w-4" />
                {exporting ? 'Exportando...' : 'Exportar PDF'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Content for PDF */}
        <div ref={reportRef} className="space-y-6">
          {/* PDF Header */}
          <div className="hidden print:block text-center mb-4">
            <h2 className="text-2xl font-bold">Relatório de Altas</h2>
            <p className="text-muted-foreground">{getPeriodTitle()}</p>
          </div>

          {/* Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Resumo - {getPeriodTitle()}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-muted rounded-lg p-4 text-center">
                  <p className="text-2xl font-bold text-primary">{totalDischarges}</p>
                  <p className="text-sm text-muted-foreground">Total de Altas</p>
                </div>
                {Object.entries(MOTIVO_ALTA_NAMES).map(([key, name]) => (
                  <div key={key} className="bg-muted rounded-lg p-4 text-center">
                    <p className="text-2xl font-bold text-primary">
                      {groupedRecords[key]?.length || 0}
                    </p>
                    <p className="text-sm text-muted-foreground">{name}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Loading */}
          {loading && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Carregando...</p>
            </div>
          )}

          {/* No records */}
          {!loading && records.length === 0 && (
            <Card>
              <CardContent className="py-8">
                <p className="text-center text-muted-foreground">
                  Nenhuma alta registrada no período selecionado.
                </p>
              </CardContent>
            </Card>
          )}

          {/* Grouped Tables by Motivo Alta */}
          {!loading && Object.entries(MOTIVO_ALTA_NAMES).map(([motivoKey, motivoName]) => {
            const motivoRecords = groupedRecords[motivoKey] || [];
            if (motivoRecords.length === 0) return null;

            return (
              <Card key={motivoKey}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{motivoName}</span>
                    <span className="text-sm font-normal bg-primary/10 text-primary px-3 py-1 rounded-full">
                      {motivoRecords.length} paciente(s)
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-20">Leito</TableHead>
                          <TableHead className="w-28">Setor</TableHead>
                          <TableHead>Paciente</TableHead>
                          <TableHead className="w-28">Nº SUS Fácil</TableHead>
                          <TableHead className="w-28">Data Internação</TableHead>
                          <TableHead className="w-36">Data/Hora Alta</TableHead>
                          {motivoKey === 'transferencia' && (
                            <TableHead>Estabelecimento Destino</TableHead>
                          )}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {motivoRecords.map((record) => (
                          <TableRow key={record.id}>
                            <TableCell className="font-medium">{record.bed_number}</TableCell>
                            <TableCell>{SECTOR_NAMES[record.sector] || record.sector}</TableCell>
                            <TableCell>{record.patient_name || '-'}</TableCell>
                            <TableCell>{record.numero_sus_facil || '-'}</TableCell>
                            <TableCell>{formatDate(record.data_internacao)}</TableCell>
                            <TableCell>{formatDateTime(record.data_alta)}</TableCell>
                            {motivoKey === 'transferencia' && (
                              <TableCell className="font-medium text-orange-600">
                                {record.estabelecimento_transferencia || '-'}
                              </TableCell>
                            )}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default DischargeReport;
