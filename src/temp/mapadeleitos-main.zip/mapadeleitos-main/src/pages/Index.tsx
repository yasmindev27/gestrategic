import { useState, useEffect, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { FileText, ClipboardList, BarChart3 } from 'lucide-react';
import { Header } from '@/components/Header';
import { ShiftConfig } from '@/components/ShiftConfig';
import { SectorTabs } from '@/components/SectorTabs';
import { BedGrid } from '@/components/BedGrid';
import { BedModal } from '@/components/BedModal';
import { OccupancySummary } from '@/components/OccupancySummary';
import { MonthlyPatientsChart } from '@/components/MonthlyPatientsChart';
import { useBeds } from '@/hooks/useBeds';
import { useBedRecords } from '@/hooks/useBedRecords';
import { useShiftConfig } from '@/hooks/useShiftConfig';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Bed, Patient, Sector, SECTORS } from '@/types/bed';

const Index = () => {
  const { shiftInfo, isLoading: isShiftLoading, updateShiftInfo, saveShiftConfig } = useShiftConfig();

  const [activeSector, setActiveSector] = useState<Sector>('enfermaria-masculina');
  const [selectedBed, setSelectedBed] = useState<Bed | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { beds, isLoading: isBedsLoading, updateBed, transferPatient, occupancyBySector, totalOccupancy } = useBeds(shiftInfo.data);
  const { saveBedRecord, updateDailyStatistics } = useBedRecords();
  
  // Track which beds have been synced to avoid duplicate saves
  const syncedBedsRef = useRef<Set<string>>(new Set());
  const syncTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Sync data to database with debouncing
  const syncToDatabase = useCallback(async () => {
    const bedsWithPatients = beds.filter(bed => bed.patient !== null);
    
    // Save only beds that haven't been synced yet or have changed
    const savePromises = bedsWithPatients.map(async (bed) => {
      const bedKey = `${bed.id}-${JSON.stringify(bed.patient)}`;
      if (!syncedBedsRef.current.has(bedKey)) {
        syncedBedsRef.current.add(bedKey);
        await saveBedRecord(bed, shiftInfo);
      }
    });

    await Promise.all(savePromises);

    // Calculate patients by sector (only countable beds)
    const patientsBySector: Record<string, number> = {};
    SECTORS.forEach(sector => {
      const sectorBeds = beds.filter(
        bed => bed.sector === sector.id && typeof bed.number === 'number' && bed.patient !== null
      );
      patientsBySector[sector.id] = sectorBeds.length;
    });

    // Update daily statistics
    const totalPatients = beds.filter(
      bed => typeof bed.number === 'number' && bed.patient !== null
    ).length;

    await updateDailyStatistics(shiftInfo.data, totalPatients, patientsBySector);
  }, [beds, shiftInfo, saveBedRecord, updateDailyStatistics]);

  // Auto-sync when beds change with debouncing
  useEffect(() => {
    if (isBedsLoading || isShiftLoading) return;
    
    const hasPatients = beds.some(bed => bed.patient !== null);
    if (!hasPatients) return;

    // Clear previous timeout
    if (syncTimeoutRef.current) {
      clearTimeout(syncTimeoutRef.current);
    }

    // Debounce sync to avoid excessive database writes
    syncTimeoutRef.current = setTimeout(() => {
      syncToDatabase();
    }, 1000);

    return () => {
      if (syncTimeoutRef.current) {
        clearTimeout(syncTimeoutRef.current);
      }
    };
  }, [beds, syncToDatabase, isBedsLoading, isShiftLoading]);

  // Reset synced beds when date changes
  useEffect(() => {
    syncedBedsRef.current.clear();
  }, [shiftInfo.data]);

  const handleBedClick = useCallback((bed: Bed) => {
    setSelectedBed(bed);
    setIsModalOpen(true);
  }, []);

  const handleSaveBed = useCallback(async (bed: Bed, patient: Patient | null, isDischarge?: boolean) => {
    // Clear the synced key for this bed so it gets saved on next sync
    syncedBedsRef.current = new Set(
      [...syncedBedsRef.current].filter(key => !key.startsWith(`${bed.id}-`))
    );
    
    if (isDischarge && patient) {
      // Se é uma alta, salvar primeiro com a data da alta
      const bedWithPatient = { ...bed, patient };
      
      // Salva o registro com a data da alta diretamente (sem debounce)
      const { error } = await supabase.from('bed_records').upsert({
        bed_id: bed.id,
        bed_number: String(bed.number),
        sector: bed.sector,
        patient_name: patient.nome,
        hipotese_diagnostica: patient.hipoteseDiagnostica,
        condutas_outros: patient.condutasOutros,
        observacao: patient.observacao,
        data_nascimento: patient.dataNascimento || null,
        data_internacao: patient.dataInternacao || null,
        sus_facil: patient.susFacil,
        numero_sus_facil: patient.numeroSusFacil,
        motivo_alta: patient.motivoAlta,
        estabelecimento_transferencia: patient.estabelecimentoTransferencia,
        shift_type: shiftInfo.tipo,
        shift_date: shiftInfo.data,
        medicos: shiftInfo.medicos,
        enfermeiros: shiftInfo.enfermeiros,
        regulador_nir: shiftInfo.reguladorNIR,
        data_alta: patient.dataAlta || new Date().toISOString(),
      }, {
        onConflict: 'bed_id,shift_date'
      });

      if (error) {
        console.error('Error saving discharge record:', error);
        return;
      }

      // Agora deleta o registro do leito para liberar (o registro histórico já foi salvo com data_alta)
      await supabase.from('bed_records').delete()
        .eq('bed_id', bed.id)
        .eq('shift_date', shiftInfo.data);
      
      // Atualiza o estado local para liberar o leito
      updateBed(bed.id, null);
    } else {
      updateBed(bed.id, patient);
    }
  }, [updateBed, shiftInfo]);

  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedBed(null);
  }, []);

  const handleTransfer = useCallback((fromBed: Bed, toBed: Bed) => {
    // Limpa os registros sincronizados para ambos os leitos
    syncedBedsRef.current = new Set(
      [...syncedBedsRef.current].filter(key => 
        !key.startsWith(`${fromBed.id}-`) && !key.startsWith(`${toBed.id}-`)
      )
    );
    transferPatient(fromBed, toBed);
  }, [transferPatient]);

  const handleSaveShiftConfig = useCallback(async () => {
    await saveShiftConfig();
  }, [saveShiftConfig]);

  const sectorBeds = beds.filter((bed) => bed.sector === activeSector);

  if (isBedsLoading || isShiftLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header shiftType={shiftInfo.tipo} shiftDate={shiftInfo.data} />

      <main className="container mx-auto px-4 py-6 space-y-6">
        <div className="flex justify-end gap-2">
          <Link to="/dashboard">
            <Button variant="outline" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <Link to="/relatorios">
            <Button variant="outline" className="gap-2">
              <FileText className="h-4 w-4" />
              Internados
            </Button>
          </Link>
          <Link to="/relatorio-altas">
            <Button variant="outline" className="gap-2">
              <ClipboardList className="h-4 w-4" />
              Altas
            </Button>
          </Link>
        </div>
        <ShiftConfig 
          shiftInfo={shiftInfo} 
          onShiftInfoChange={updateShiftInfo} 
          onSave={handleSaveShiftConfig}
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <OccupancySummary
            occupied={totalOccupancy.occupied}
            total={totalOccupancy.total}
          />
          <MonthlyPatientsChart />
        </div>

        <SectorTabs
          activeSector={activeSector}
          onSectorChange={setActiveSector}
          occupancyBySector={occupancyBySector}
        />

        <BedGrid
          sector={activeSector}
          beds={sectorBeds}
          onBedClick={handleBedClick}
        />
      </main>

      <BedModal
        bed={selectedBed}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSaveBed}
        sectorBeds={sectorBeds}
        onTransfer={handleTransfer}
      />
    </div>
  );
};

export default Index;
