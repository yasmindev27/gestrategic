import { useState, useEffect, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Download, TrendingUp, TrendingDown, Users, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { format, parseISO, eachDayOfInterval, eachMonthOfInterval, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LineChart,
  Line,
  CartesianGrid,
} from 'recharts';
import html2pdf from 'html2pdf.js';
import { PeriodSelector, PeriodType } from '@/components/PeriodSelector';

interface DailyData {
  date: string;
  dateLabel: string;
  admissions: number;
  discharges: number;
}

interface SummaryData {
  totalAdmissions: number;
  totalDischarges: number;
  averageAdmissions: number;
  averageDischarges: number;
}

export default function Dashboard() {
  const [startDate, setStartDate] = useState(() => format(startOfMonth(new Date()), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(() => format(new Date(), 'yyyy-MM-dd'));
  const [periodType, setPeriodType] = useState<PeriodType>('monthly');
  const [dailyData, setDailyData] = useState<DailyData[]>([]);
  const [summary, setSummary] = useState<SummaryData>({
    totalAdmissions: 0,
    totalDischarges: 0,
    averageAdmissions: 0,
    averageDischarges: 0,
  });
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const dashboardRef = useRef<HTMLDivElement>(null);

  const handlePeriodChange = useCallback((start: string, end: string, type: PeriodType) => {
    setStartDate(start);
    setEndDate(end);
    setPeriodType(type);
  }, []);

  const fetchData = useCallback(async () => {
    if (!startDate || !endDate) return;
    
    setLoading(true);
    try {
      const { data: records, error } = await supabase
        .from('bed_records')
        .select('data_internacao, data_alta, shift_date, patient_name')
        .gte('shift_date', startDate)
        .lte('shift_date', endDate)
        .not('patient_name', 'is', null);

      if (error) {
        console.error('Error fetching data:', error);
        return;
      }

      let chartData: DailyData[];

      if (periodType === 'yearly') {
        // Group by month for yearly view
        const monthRange = eachMonthOfInterval({
          start: parseISO(startDate),
          end: parseISO(endDate),
        });

        const dataByMonth: Record<string, { admissions: number; discharges: number }> = {};
        
        monthRange.forEach(date => {
          const monthStr = format(date, 'yyyy-MM');
          dataByMonth[monthStr] = { admissions: 0, discharges: 0 };
        });

        const uniqueAdmissions = new Set<string>();
        const uniqueDischarges = new Set<string>();

        (records || []).forEach(record => {
          if (record.data_internacao && record.patient_name) {
            const monthStr = format(parseISO(record.data_internacao), 'yyyy-MM');
            const admissionKey = `${record.patient_name}-${record.data_internacao}`;
            if (!uniqueAdmissions.has(admissionKey) && dataByMonth[monthStr]) {
              uniqueAdmissions.add(admissionKey);
              dataByMonth[monthStr].admissions++;
            }
          }

          if (record.data_alta && record.patient_name) {
            const dischargeDate = format(parseISO(record.data_alta), 'yyyy-MM-dd');
            const monthStr = format(parseISO(record.data_alta), 'yyyy-MM');
            const dischargeKey = `${record.patient_name}-${dischargeDate}`;
            if (!uniqueDischarges.has(dischargeKey) && dataByMonth[monthStr]) {
              uniqueDischarges.add(dischargeKey);
              dataByMonth[monthStr].discharges++;
            }
          }
        });

        chartData = monthRange.map(date => {
          const monthStr = format(date, 'yyyy-MM');
          return {
            date: monthStr,
            dateLabel: format(date, 'MMM/yy', { locale: ptBR }),
            admissions: dataByMonth[monthStr]?.admissions || 0,
            discharges: dataByMonth[monthStr]?.discharges || 0,
          };
        });
      } else {
        // Daily view for daily/monthly
        const dateRange = eachDayOfInterval({
          start: parseISO(startDate),
          end: parseISO(endDate),
        });

        const dataByDate: Record<string, { admissions: number; discharges: number }> = {};
        
        dateRange.forEach(date => {
          const dateStr = format(date, 'yyyy-MM-dd');
          dataByDate[dateStr] = { admissions: 0, discharges: 0 };
        });

        const uniqueAdmissions = new Set<string>();
        const uniqueDischarges = new Set<string>();

        (records || []).forEach(record => {
          if (record.data_internacao && record.patient_name) {
            const admissionKey = `${record.patient_name}-${record.data_internacao}`;
            if (!uniqueAdmissions.has(admissionKey) && dataByDate[record.data_internacao]) {
              uniqueAdmissions.add(admissionKey);
              dataByDate[record.data_internacao].admissions++;
            }
          }

          if (record.data_alta && record.patient_name) {
            const dischargeDate = format(parseISO(record.data_alta), 'yyyy-MM-dd');
            const dischargeKey = `${record.patient_name}-${dischargeDate}`;
            if (!uniqueDischarges.has(dischargeKey) && dataByDate[dischargeDate]) {
              uniqueDischarges.add(dischargeKey);
              dataByDate[dischargeDate].discharges++;
            }
          }
        });

        chartData = dateRange.map(date => {
          const dateStr = format(date, 'yyyy-MM-dd');
          return {
            date: dateStr,
            dateLabel: format(date, 'dd/MM', { locale: ptBR }),
            admissions: dataByDate[dateStr]?.admissions || 0,
            discharges: dataByDate[dateStr]?.discharges || 0,
          };
        });
      }

      setDailyData(chartData);

      const totalAdmissions = chartData.reduce((sum, d) => sum + d.admissions, 0);
      const totalDischarges = chartData.reduce((sum, d) => sum + d.discharges, 0);
      const periods = chartData.length || 1;

      setSummary({
        totalAdmissions,
        totalDischarges,
        averageAdmissions: Math.round((totalAdmissions / periods) * 10) / 10,
        averageDischarges: Math.round((totalDischarges / periods) * 10) / 10,
      });
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate, periodType]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('dashboard-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bed_records',
        },
        () => {
          fetchData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchData]);

  const exportToPDF = async () => {
    if (!dashboardRef.current) return;

    setExporting(true);
    try {
      const element = dashboardRef.current;
      const periodLabel = periodType === 'daily' ? startDate : 
                         periodType === 'monthly' ? format(parseISO(startDate), 'yyyy-MM') : 
                         format(parseISO(startDate), 'yyyy');
      const opt = {
        margin: 10,
        filename: `dashboard-internacoes-${periodLabel}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' },
      };

      await html2pdf().set(opt).from(element).save();
    } catch (error) {
      console.error('Erro ao exportar PDF:', error);
    } finally {
      setExporting(false);
    }
  };

  const getPeriodTitle = () => {
    switch (periodType) {
      case 'daily':
        return format(parseISO(startDate), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
      case 'monthly':
        return format(parseISO(startDate), "MMMM 'de' yyyy", { locale: ptBR });
      case 'yearly':
        return `Ano de ${format(parseISO(startDate), 'yyyy')}`;
    }
  };

  const getAverageLabel = () => {
    return periodType === 'yearly' ? 'pacientes/mês' : 'pacientes/dia';
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold text-foreground">Dashboard de Internações</h1>
              <p className="text-sm text-muted-foreground">Série histórica de internações e altas</p>
            </div>
          </div>
          <Button onClick={exportToPDF} disabled={exporting} className="gap-2">
            <Download className="h-4 w-4" />
            {exporting ? 'Exportando...' : 'Exportar PDF'}
          </Button>
        </div>
      </header>

      <main className="container mx-auto p-4 space-y-6">
        {/* Period Filter */}
        <Card>
          <CardHeader>
            <CardTitle>Selecionar Período</CardTitle>
          </CardHeader>
          <CardContent>
            <PeriodSelector onPeriodChange={handlePeriodChange} showDaily={false} />
          </CardContent>
        </Card>

        {/* Content for PDF export */}
        <div ref={dashboardRef} className="space-y-6 bg-background p-4">
          <div className="text-center mb-4 print:block hidden">
            <h2 className="text-2xl font-bold">Dashboard de Internações</h2>
            <p className="text-muted-foreground">{getPeriodTitle()}</p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Internações</CardTitle>
                <TrendingUp className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{summary.totalAdmissions}</div>
                <p className="text-xs text-muted-foreground">{getPeriodTitle()}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Altas</CardTitle>
                <TrendingDown className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{summary.totalDischarges}</div>
                <p className="text-xs text-muted-foreground">{getPeriodTitle()}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Média de Internações</CardTitle>
                <Users className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{summary.averageAdmissions}</div>
                <p className="text-xs text-muted-foreground">{getAverageLabel()}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Média de Altas</CardTitle>
                <Calendar className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{summary.averageDischarges}</div>
                <p className="text-xs text-muted-foreground">{getAverageLabel()}</p>
              </CardContent>
            </Card>
          </div>

          {/* Bar Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Internações e Altas - {getPeriodTitle()}</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-[300px] flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : dailyData.length === 0 ? (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  Nenhum dado encontrado para o período selecionado
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={dailyData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="dateLabel" 
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                      allowDecimals={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Legend />
                    <Bar 
                      dataKey="admissions" 
                      name="Internações" 
                      fill="hsl(142, 76%, 36%)" 
                      radius={[4, 4, 0, 0]} 
                    />
                    <Bar 
                      dataKey="discharges" 
                      name="Altas" 
                      fill="hsl(217, 91%, 60%)" 
                      radius={[4, 4, 0, 0]} 
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Line Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Tendência de Internações e Altas</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-[300px] flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : dailyData.length === 0 ? (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  Nenhum dado encontrado para o período selecionado
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={dailyData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="dateLabel" 
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                      allowDecimals={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="admissions" 
                      name="Internações" 
                      stroke="hsl(142, 76%, 36%)" 
                      strokeWidth={2}
                      dot={{ fill: 'hsl(142, 76%, 36%)' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="discharges" 
                      name="Altas" 
                      stroke="hsl(217, 91%, 60%)" 
                      strokeWidth={2}
                      dot={{ fill: 'hsl(217, 91%, 60%)' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Data Table */}
          <Card>
            <CardHeader>
              <CardTitle>Detalhamento {periodType === 'yearly' ? 'Mensal' : 'Diário'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2 font-medium">{periodType === 'yearly' ? 'Mês' : 'Data'}</th>
                      <th className="text-center p-2 font-medium">Internações</th>
                      <th className="text-center p-2 font-medium">Altas</th>
                      <th className="text-center p-2 font-medium">Saldo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dailyData.map((day) => (
                      <tr key={day.date} className="border-b hover:bg-muted/50">
                        <td className="p-2">
                          {periodType === 'yearly' 
                            ? format(parseISO(day.date + '-01'), "MMMM 'de' yyyy", { locale: ptBR })
                            : format(parseISO(day.date), "dd/MM/yyyy (EEEE)", { locale: ptBR })
                          }
                        </td>
                        <td className="text-center p-2">
                          <span className="text-green-600 font-medium">{day.admissions}</span>
                        </td>
                        <td className="text-center p-2">
                          <span className="text-blue-600 font-medium">{day.discharges}</span>
                        </td>
                        <td className="text-center p-2">
                          <span className={`font-medium ${day.admissions - day.discharges >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {day.admissions - day.discharges >= 0 ? '+' : ''}{day.admissions - day.discharges}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-muted/50 font-bold">
                      <td className="p-2">Total</td>
                      <td className="text-center p-2 text-green-600">{summary.totalAdmissions}</td>
                      <td className="text-center p-2 text-blue-600">{summary.totalDischarges}</td>
                      <td className="text-center p-2">
                        <span className={summary.totalAdmissions - summary.totalDischarges >= 0 ? 'text-green-600' : 'text-red-600'}>
                          {summary.totalAdmissions - summary.totalDischarges >= 0 ? '+' : ''}
                          {summary.totalAdmissions - summary.totalDischarges}
                        </span>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
