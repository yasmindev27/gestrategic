import { useState, useEffect, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, FileText, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { format, parseISO, differenceInYears, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import html2pdf from 'html2pdf.js';
import { PeriodSelector, PeriodType } from '@/components/PeriodSelector';

const SECTOR_NAMES: Record<string, string> = {
  'enfermaria-masculina': 'Enfermaria Masculina',
  'enfermaria-feminina': 'Enfermaria Feminina',
  'pediatria': 'Pediatria',
  'isolamento': 'Isolamento',
  'urgencia': 'Urgência',
};

interface BedRecord {
  bed_id: string;
  bed_number: string;
  sector: string;
  patient_name: string | null;
  data_nascimento: string | null;
  data_internacao: string | null;
  hipotese_diagnostica: string | null;
  sus_facil: string | null;
  numero_sus_facil: string | null;
  observacao: string | null;
  shift_date: string;
  data_alta: string | null;
}

const Reports = () => {
  const [startDate, setStartDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [periodType, setPeriodType] = useState<PeriodType>('daily');
  const [records, setRecords] = useState<BedRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const handlePeriodChange = useCallback((start: string, end: string, type: PeriodType) => {
    setStartDate(start);
    setEndDate(end);
    setPeriodType(type);
  }, []);

  const exportToPDF = async () => {
    if (!reportRef.current || records.length === 0) return;
    
    setExporting(true);
    try {
      const element = reportRef.current;
      const periodLabel = periodType === 'daily' ? startDate : 
                         periodType === 'monthly' ? format(parseISO(startDate), 'yyyy-MM') : 
                         format(parseISO(startDate), 'yyyy');
      const opt = {
        margin: [10, 10, 10, 10],
        filename: `relatorio-internados-${periodLabel}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
      };
      
      await html2pdf().set(opt).from(element).save();
    } catch (error) {
      console.error('Erro ao exportar PDF:', error);
    } finally {
      setExporting(false);
    }
  };

  const fetchRecords = useCallback(async () => {
    setLoading(true);
    try {
      // Busca pacientes que estavam internados no período (data_internacao <= endDate)
      // e que não receberam alta antes do período (data_alta IS NULL ou data_alta >= startDate)
      const { data, error } = await supabase
        .from('bed_records')
        .select('bed_id, bed_number, sector, patient_name, data_nascimento, data_internacao, hipotese_diagnostica, sus_facil, numero_sus_facil, observacao, shift_date, data_alta')
        .not('patient_name', 'is', null)
        .lte('data_internacao', endDate)
        .order('shift_date', { ascending: false })
        .order('sector')
        .order('bed_number');

      if (error) throw error;
      
      // Filtra registros: internação começou antes do fim do período
      // e não teve alta antes do início do período
      const filteredData = (data || []).filter(record => {
        if (!record.data_internacao) return false;
        
        const internacaoDate = record.data_internacao;
        const altaDate = record.data_alta ? record.data_alta.split('T')[0] : null;
        
        // Paciente deve ter internado até o fim do período
        if (internacaoDate > endDate) return false;
        
        // Se teve alta antes do início do período, não incluir
        if (altaDate && altaDate < startDate) return false;
        
        return true;
      });
      
      // Remove duplicates by patient_name (keep latest shift_date record)
      const uniqueRecords = filteredData.reduce((acc: BedRecord[], record) => {
        const existing = acc.find(r => r.patient_name === record.patient_name);
        if (!existing) {
          acc.push(record);
        }
        return acc;
      }, []);

      setRecords(uniqueRecords);
    } catch (error) {
      console.error('Erro ao buscar registros:', error);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate]);

  useEffect(() => {
    fetchRecords();
  }, [fetchRecords]);

  // Real-time subscription for bed_records changes
  useEffect(() => {
    const channel = supabase
      .channel('bed-records-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bed_records',
        },
        () => {
          fetchRecords();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchRecords]);

  const calculateAge = (birthDate: string | null): string => {
    if (!birthDate) return '-';
    try {
      const birth = parseISO(birthDate);
      const age = differenceInYears(new Date(), birth);
      return `${age} anos`;
    } catch {
      return '-';
    }
  };

  const calculateDaysHospitalized = (admissionDate: string | null): string => {
    if (!admissionDate) return '-';
    try {
      const admission = parseISO(admissionDate);
      const days = differenceInDays(new Date(), admission);
      return `${days} dia${days !== 1 ? 's' : ''}`;
    } catch {
      return '-';
    }
  };

  const formatDate = (date: string | null): string => {
    if (!date) return '-';
    try {
      return format(parseISO(date), 'dd/MM/yyyy', { locale: ptBR });
    } catch {
      return '-';
    }
  };

  const getPeriodTitle = () => {
    switch (periodType) {
      case 'daily':
        return format(parseISO(startDate), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
      case 'monthly':
        return format(parseISO(startDate), "MMMM 'de' yyyy", { locale: ptBR });
      case 'yearly':
        return `Ano de ${format(parseISO(startDate), 'yyyy')}`;
    }
  };

  // Group by sector and optionally by date for monthly/yearly
  const recordsBySector = records.reduce((acc, record) => {
    if (!acc[record.sector]) {
      acc[record.sector] = [];
    }
    acc[record.sector].push(record);
    return acc;
  }, {} as Record<string, BedRecord[]>);

  const sectorOrder = ['enfermaria-masculina', 'enfermaria-feminina', 'pediatria', 'isolamento', 'urgencia'];
  const sortedSectors = sectorOrder.filter(sector => recordsBySector[sector]?.length > 0);

  // Get unique patients count for summary
  const uniquePatients = new Set(records.map(r => r.patient_name)).size;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground py-4 px-6 shadow-md">
        <div className="container mx-auto flex items-center gap-4">
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary-foreground/10">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <FileText className="h-6 w-6" />
            <h1 className="text-xl font-bold">Relatório de Pacientes Internados</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Selecionar Período</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
              <PeriodSelector onPeriodChange={handlePeriodChange} showDaily={true} />
              <Button 
                onClick={exportToPDF} 
                disabled={exporting || records.length === 0}
                className="gap-2 self-start lg:self-auto"
              >
                <Download className="h-4 w-4" />
                {exporting ? 'Exportando...' : 'Exportar PDF'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              Carregando...
            </CardContent>
          </Card>
        ) : records.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              Nenhum paciente internado encontrado para este período.
            </CardContent>
          </Card>
        ) : (
          <div ref={reportRef} className="space-y-6">
            {/* PDF Header */}
            <div className="hidden print:block text-center mb-4">
              <h2 className="text-2xl font-bold">Relatório de Pacientes Internados</h2>
              <p className="text-muted-foreground">{getPeriodTitle()}</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Resumo - {getPeriodTitle()}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{records.length}</div>
                    <div className="text-sm text-muted-foreground">Total Registros</div>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{uniquePatients}</div>
                    <div className="text-sm text-muted-foreground">Pacientes Únicos</div>
                  </div>
                  {sortedSectors.map(sector => (
                    <div key={sector} className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-primary">{recordsBySector[sector].length}</div>
                      <div className="text-sm text-muted-foreground">{SECTOR_NAMES[sector]}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {sortedSectors.map(sector => (
              <Card key={sector}>
                <CardHeader>
                  <CardTitle className="text-lg">
                    {SECTOR_NAMES[sector]} ({recordsBySector[sector].length} registro{recordsBySector[sector].length !== 1 ? 's' : ''})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          {periodType !== 'daily' && <TableHead className="w-24">Data Reg.</TableHead>}
                          <TableHead className="w-20">Leito</TableHead>
                          <TableHead>Paciente</TableHead>
                          <TableHead className="w-24">Idade</TableHead>
                          <TableHead className="w-28">Internação</TableHead>
                          <TableHead className="w-24">Dias Int.</TableHead>
                          <TableHead>Hipótese Diagnóstica</TableHead>
                          <TableHead className="w-24">SUS Fácil</TableHead>
                          <TableHead className="w-32">Nº SUS Fácil</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {recordsBySector[sector].map((record, idx) => (
                          <TableRow key={`${record.bed_id}-${record.shift_date}-${idx}`}>
                            {periodType !== 'daily' && <TableCell>{formatDate(record.shift_date)}</TableCell>}
                            <TableCell className="font-medium">{record.bed_number}</TableCell>
                            <TableCell>{record.patient_name || '-'}</TableCell>
                            <TableCell>{calculateAge(record.data_nascimento)}</TableCell>
                            <TableCell>{formatDate(record.data_internacao)}</TableCell>
                            <TableCell>{calculateDaysHospitalized(record.data_internacao)}</TableCell>
                            <TableCell className="max-w-xs truncate">{record.hipotese_diagnostica || '-'}</TableCell>
                            <TableCell>
                              {record.sus_facil === 'sim' ? (
                                <span className="text-green-600 font-medium">Sim</span>
                              ) : record.sus_facil === 'nao' ? (
                                <span className="text-red-600 font-medium">Não</span>
                              ) : '-'}
                            </TableCell>
                            <TableCell>{record.numero_sus_facil || '-'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Reports;
