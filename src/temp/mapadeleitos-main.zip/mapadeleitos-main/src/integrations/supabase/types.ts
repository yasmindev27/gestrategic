export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      bed_records: {
        Row: {
          bed_id: string
          bed_number: string
          condutas_outros: string | null
          created_at: string
          data_alta: string | null
          data_internacao: string | null
          data_nascimento: string | null
          enfermeiros: string | null
          estabelecimento_transferencia: string | null
          hipotese_diagnostica: string | null
          id: string
          medicos: string | null
          motivo_alta: string | null
          numero_sus_facil: string | null
          observacao: string | null
          patient_name: string | null
          regulador_nir: string | null
          sector: string
          shift_date: string
          shift_type: string
          sus_facil: string | null
          updated_at: string
        }
        Insert: {
          bed_id: string
          bed_number: string
          condutas_outros?: string | null
          created_at?: string
          data_alta?: string | null
          data_internacao?: string | null
          data_nascimento?: string | null
          enfermeiros?: string | null
          estabelecimento_transferencia?: string | null
          hipotese_diagnostica?: string | null
          id?: string
          medicos?: string | null
          motivo_alta?: string | null
          numero_sus_facil?: string | null
          observacao?: string | null
          patient_name?: string | null
          regulador_nir?: string | null
          sector: string
          shift_date: string
          shift_type: string
          sus_facil?: string | null
          updated_at?: string
        }
        Update: {
          bed_id?: string
          bed_number?: string
          condutas_outros?: string | null
          created_at?: string
          data_alta?: string | null
          data_internacao?: string | null
          data_nascimento?: string | null
          enfermeiros?: string | null
          estabelecimento_transferencia?: string | null
          hipotese_diagnostica?: string | null
          id?: string
          medicos?: string | null
          motivo_alta?: string | null
          numero_sus_facil?: string | null
          observacao?: string | null
          patient_name?: string | null
          regulador_nir?: string | null
          sector?: string
          shift_date?: string
          shift_type?: string
          sus_facil?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      daily_statistics: {
        Row: {
          created_at: string
          date: string
          id: string
          patients_by_sector: Json
          total_patients: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          date: string
          id?: string
          patients_by_sector?: Json
          total_patients?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          date?: string
          id?: string
          patients_by_sector?: Json
          total_patients?: number
          updated_at?: string
        }
        Relationships: []
      }
      shift_configurations: {
        Row: {
          created_at: string
          enfermeiros: string | null
          id: string
          medicos: string | null
          regulador_nir: string | null
          shift_date: string
          shift_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          enfermeiros?: string | null
          id?: string
          medicos?: string | null
          regulador_nir?: string | null
          shift_date: string
          shift_type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          enfermeiros?: string | null
          id?: string
          medicos?: string | null
          regulador_nir?: string | null
          shift_date?: string
          shift_type?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
