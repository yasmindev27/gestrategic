-- First, delete duplicate records keeping only the most recent one
DELETE FROM public.bed_records a
USING public.bed_records b
WHERE a.bed_id = b.bed_id 
  AND a.shift_date = b.shift_date 
  AND a.created_at < b.created_at;

-- Add unique constraint to prevent future duplicates
ALTER TABLE public.bed_records 
ADD CONSTRAINT bed_records_bed_id_shift_date_unique UNIQUE (bed_id, shift_date);