-- Create table to store shift configurations by date
CREATE TABLE public.shift_configurations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  shift_date DATE NOT NULL,
  shift_type TEXT NOT NULL,
  medicos TEXT,
  enfermeiros TEXT,
  regulador_nir TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT shift_configurations_date_unique UNIQUE (shift_date)
);

-- Enable RLS
ALTER TABLE public.shift_configurations ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (same as other tables)
CREATE POLICY "Anyone can view shift configurations"
ON public.shift_configurations FOR SELECT
USING (true);

CREATE POLICY "Anyone can insert shift configurations"
ON public.shift_configurations FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can update shift configurations"
ON public.shift_configurations FOR UPDATE
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_shift_configurations_updated_at
BEFORE UPDATE ON public.shift_configurations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();