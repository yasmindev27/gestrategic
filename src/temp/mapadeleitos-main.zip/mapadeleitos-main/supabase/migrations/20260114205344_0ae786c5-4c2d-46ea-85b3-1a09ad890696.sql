-- Add data_alta column to store discharge date/time
ALTER TABLE public.bed_records 
ADD COLUMN data_alta timestamp with time zone DEFAULT NULL;