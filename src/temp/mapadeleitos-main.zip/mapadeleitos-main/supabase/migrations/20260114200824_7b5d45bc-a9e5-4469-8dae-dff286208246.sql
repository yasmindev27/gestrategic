-- Drop the existing unique constraint on shift_date only
ALTER TABLE public.shift_configurations 
DROP CONSTRAINT IF EXISTS shift_configurations_date_unique;

-- Add new unique constraint on shift_date + shift_type combination
ALTER TABLE public.shift_configurations 
ADD CONSTRAINT shift_configurations_date_type_unique UNIQUE (shift_date, shift_type);