-- Add numero_sus_facil column to bed_records table
ALTER TABLE public.bed_records 
ADD COLUMN numero_sus_facil text;