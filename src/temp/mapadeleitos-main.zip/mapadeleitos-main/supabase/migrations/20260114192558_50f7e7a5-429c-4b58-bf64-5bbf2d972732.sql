-- Create table for daily bed records
CREATE TABLE public.bed_records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  bed_id TEXT NOT NULL,
  bed_number TEXT NOT NULL,
  sector TEXT NOT NULL,
  patient_name TEXT,
  hipotese_diagnostica TEXT,
  condutas_outros TEXT,
  observacao TEXT,
  data_nascimento DATE,
  data_internacao DATE,
  sus_facil TEXT,
  motivo_alta TEXT,
  estabelecimento_transferencia TEXT,
  shift_type TEXT NOT NULL,
  shift_date DATE NOT NULL,
  medicos TEXT,
  enfermeiros TEXT,
  regulador_nir TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster queries
CREATE INDEX idx_bed_records_shift_date ON public.bed_records(shift_date);
CREATE INDEX idx_bed_records_sector ON public.bed_records(sector);

-- Enable Row Level Security
ALTER TABLE public.bed_records ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (since this is a hospital system without user auth)
CREATE POLICY "Anyone can view bed records"
ON public.bed_records
FOR SELECT
USING (true);

CREATE POLICY "Anyone can insert bed records"
ON public.bed_records
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can update bed records"
ON public.bed_records
FOR UPDATE
USING (true);

CREATE POLICY "Anyone can delete bed records"
ON public.bed_records
FOR DELETE
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_bed_records_updated_at
BEFORE UPDATE ON public.bed_records
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create table for daily statistics
CREATE TABLE public.daily_statistics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  date DATE NOT NULL UNIQUE,
  total_patients INTEGER NOT NULL DEFAULT 0,
  patients_by_sector JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for daily_statistics
ALTER TABLE public.daily_statistics ENABLE ROW LEVEL SECURITY;

-- Create policies for daily_statistics
CREATE POLICY "Anyone can view daily statistics"
ON public.daily_statistics
FOR SELECT
USING (true);

CREATE POLICY "Anyone can insert daily statistics"
ON public.daily_statistics
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can update daily statistics"
ON public.daily_statistics
FOR UPDATE
USING (true);

-- Create trigger for daily_statistics timestamp
CREATE TRIGGER update_daily_statistics_updated_at
BEFORE UPDATE ON public.daily_statistics
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();