-- Adicionar índices para melhorar performance das queries mais usadas

-- Índice para busca por shift_date (muito usada)
CREATE INDEX IF NOT EXISTS idx_bed_records_shift_date ON public.bed_records(shift_date);

-- Índice para busca por shift_date + shift_type
CREATE INDEX IF NOT EXISTS idx_bed_records_shift_date_type ON public.bed_records(shift_date, shift_type);

-- Índice para busca por bed_id + shift_date (usado no upsert)
CREATE INDEX IF NOT EXISTS idx_bed_records_bed_id_shift_date ON public.bed_records(bed_id, shift_date);

-- Índice para busca por sector
CREATE INDEX IF NOT EXISTS idx_bed_records_sector ON public.bed_records(sector);

-- Índice para busca por data_internacao (usado no gráfico mensal)
CREATE INDEX IF NOT EXISTS idx_bed_records_data_internacao ON public.bed_records(data_internacao);

-- Índice composto para a query do gráfico mensal (data_internacao = shift_date)
CREATE INDEX IF NOT EXISTS idx_bed_records_internacao_shift ON public.bed_records(data_internacao, shift_date);

-- Índice para daily_statistics por data
CREATE INDEX IF NOT EXISTS idx_daily_statistics_date ON public.daily_statistics(date);

-- Índice para shift_configurations por data e tipo
CREATE INDEX IF NOT EXISTS idx_shift_configurations_date_type ON public.shift_configurations(shift_date, shift_type);